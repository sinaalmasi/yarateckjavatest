package karamoziPro;

public class Applicant {
	private String name;
	private String jobPosition;
	private String id;
	private int workExperience;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getJobPosition() {
		return jobPosition;
	}
	
	public void setJobPosition(String jobPosition) {
		this.jobPosition = jobPosition;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public int getWorkExperience() {
		return workExperience;
	}
	
	public void setWorkExperience(int workExperience) {
		this.workExperience = workExperience;
	}
}